const { chromium } = require("playwright");
const fs = require("fs");

(async () => {
  const diagnostics = {
    consoleErrors: 0,
    consoleWarnings: 0,
    pageErrors: 0,
    failedRequests: 0,
    httpErrors: 0,
  };
  const actionLog = [];
  const seguradora = "Tokio";
  const loginScreenTimeoutMs = 5_000;
  const localElementTimeoutMs = 1_000;
  const faturamentoScreenTimeoutMs = 5_000;

  function register(action, detail = "") {
    const timestamp = new Date().toLocaleTimeString("pt-BR", {
      hour12: false,
    });
    const message = detail
      ? `[LOG REGISTER] ${timestamp} | ${action} | ${detail}`
      : `[LOG REGISTER] ${timestamp} | ${action}`;

    actionLog.push(message);
    console.log(message);
  }

  function loadEnvFile(filePath) {
    if (!fs.existsSync(filePath)) {
      return {};
    }

    return fs
      .readFileSync(filePath, "utf8")
      .split(/\r?\n/)
      .filter((line) => line.trim() && !line.trim().startsWith("#"))
      .reduce((env, line) => {
        const [key, ...valueParts] = line.split("=");
        const value = valueParts
          .join("=")
          .trim()
          .replace(/^["']|["']$/g, "");

        env[key.trim()] = value;
        return env;
      }, {});
  }

  function normalizeCnpj(cnpj) {
    return String(cnpj || "").replace(/\D/g, "");
  }

  function formatPtBrDateTime(date = new Date()) {
    return new Intl.DateTimeFormat("pt-BR", {
      timeZone: "America/Sao_Paulo",
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false,
    }).format(date);
  }

  async function httpJson(url, options = {}) {
    const response = await fetch(url, options);
    const text = await response.text();
    const data = text ? JSON.parse(text) : null;

    if (!response.ok) {
      throw new Error(`HTTP ${response.status} em ${url}: ${text}`);
    }

    return data;
  }

  async function redisGet(host, key) {
    const data = await httpJson(`${host}/api/redis/get`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ key }),
    });
    let value = data;

    if (data && Object.prototype.hasOwnProperty.call(data, "value")) {
      value = data.value;
    } else if (
      data?.data &&
      Object.prototype.hasOwnProperty.call(data.data, "value")
    ) {
      value = data.data.value;
    } else if (data && Object.prototype.hasOwnProperty.call(data, "result")) {
      value = data.result;
    } else if (data && Object.prototype.hasOwnProperty.call(data, "data")) {
      value = data.data;
    }

    if (value == null) {
      return null;
    }

    if (typeof value === "string") {
      try {
        return JSON.parse(value);
      } catch {
        return value;
      }
    }

    return value;
  }

  async function redisSet(host, key, value) {
    return httpJson(`${host}/api/redis/set`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ key, value: JSON.stringify(value) }),
    });
  }

  async function fetchFirstOs(host) {
    const url = `${host}/dashboard/os-login-senhas?limit=20&seguradora=${encodeURIComponent(
      seguradora
    )}&incluir_senha=true`;

    register("Consultando API de OS", `seguradora=${seguradora}`);
    const payload = await httpJson(url, {
      method: "GET",
      headers: { Accept: "application/json" },
    });
    const item = payload?.items?.[0];

    if (!item) {
      throw new Error("API nao retornou nenhuma OS para processamento.");
    }

    const credential = item.credenciais?.[0];

    if (!credential?.usuario || !credential?.senha) {
      throw new Error(
        `OS ${item.os} sem credenciais validas. Status=${item.credenciaisStatus}`
      );
    }

    register("OS selecionada", `id=${item.id} | os=${item.os} | sinistro=${item.dadosOs?.sinistro}`);
    return { payload, item, credential };
  }

  const env = {
    ...loadEnvFile(".env.example"),
    ...loadEnvFile(".env"),
    ...process.env,
  };
  const host = env.HOST;

  if (!host) {
    throw new Error("HOST nao definido em .env.example, .env ou ambiente.");
  }

  const { item: osItem, credential } = await fetchFirstOs(host);
  const redisKey = `rpa_tokio:${osItem.os}`;
  const redisState = await redisGet(host, redisKey).catch((error) => {
    register("Falha ao consultar Redis", error.message);
    throw error;
  });

  if (redisState?.verificado === true) {
    const result = {
      sucesso: true,
      ignorado: true,
      motivo: "OS ja verificada pelo RPA Tokio.",
      redisKey,
      redisState,
      osId: osItem.id,
      os: osItem.os,
      sinistro: osItem.dadosOs?.sinistro,
    };

    register("OS ja processada", `redisKey=${redisKey}`);
    console.log(JSON.stringify(result, null, 2));
    return;
  }

  const browser = await chromium.launch({
    headless: env.HEADLESS === "true",
    args: ["--disable-http2", "--no-sandbox", "--disable-dev-shm-usage"],
  });

  const page = await browser.newPage();

  async function waitForLoginScreen() {
    register("Aguardando tela de login", `timeout=${loginScreenTimeoutMs}ms`);

    const firstInput = page.locator("input").first();
    const loaded = await firstInput
      .waitFor({ state: "visible", timeout: loginScreenTimeoutMs })
      .then(() => true)
      .catch(() => false);

    if (loaded) {
      register("Tela de login encontrada");
      return;
    }

    register(
      "Tela de login nao encontrada",
      `apos ${loginScreenTimeoutMs / 1_000}s; salvando screenshot e fechando`
    );
    await page.screenshot({ path: "tokio-login-blank.png", fullPage: true });
    await browser.close();
    process.exit(1);
  }

  async function closeOficinaPopup() {
    const popup = page.locator("#modalAlertaOficina");
    const closeButton = popup.locator(
      'button.close.custom[data-dismiss="modal"][aria-label="Close"]'
    );

    register("Validando existencia do popup Oficina");
    if ((await popup.count()) === 0) {
      register("Popup Oficina nao existe no DOM");
      return;
    }

    register("Validando existencia do botao Close do popup Oficina");
    if ((await closeButton.count()) === 0) {
      register("Botao Close do popup Oficina nao existe no DOM");
      return;
    }

    register("Aguardando popup Oficina", "timeout=10000ms");
    const popupAppeared = await page
      .waitForFunction(
        () => {
          const modal = document.querySelector("#modalAlertaOficina");

          return modal && window.getComputedStyle(modal).display !== "none";
        },
        undefined,
        { timeout: 10_000 }
      )
      .then(() => true)
      .catch(() => false);

    if (!popupAppeared) {
      register("Popup Oficina nao apareceu");
      return;
    }

    if (!(await closeButton.isVisible({ timeout: 1_000 }).catch(() => false))) {
      register("Botao Close do popup Oficina existe, mas nao esta visivel");
      return;
    }

    register("Clicando no botao Close do popup Oficina");
    await closeButton.click({ force: true, timeout: 3_000 });

    const closed = await popup
      .waitFor({ state: "hidden", timeout: 2_000 })
      .then(() => true)
      .catch(() => false);

    if (closed) {
      register("Popup Oficina fechado");
      return;
    }

    register("Popup Oficina ainda visivel", "fechando via Bootstrap/jQuery");
    await page.evaluate(() => {
      const modal = document.querySelector("#modalAlertaOficina");

      if (window.jQuery) {
        window.jQuery("#modalAlertaOficina").modal("hide");
      }

      modal?.classList.remove("show", "in");
      modal?.setAttribute("aria-hidden", "true");
      modal?.setAttribute("style", "display: none;");
      document.body.classList.remove("modal-open");
      document.querySelectorAll(".modal-backdrop").forEach((backdrop) => {
        backdrop.remove();
      });
    });
    register("Popup Oficina fechado via fallback");
  }

  async function openConsultaProcessos() {
    const consultaProcessos = page
      .getByRole("menuitem", { name: /consulta processos/i })
      .or(page.getByRole("link", { name: /consulta processos/i }))
      .first();

    register("Validando existencia do menu Consulta Processos");
    if ((await consultaProcessos.count()) === 0) {
      register("Menu Consulta Processos nao existe no DOM");
      return;
    }

    register("Aguardando menu Consulta Processos", `timeout=${localElementTimeoutMs}ms`);
    await consultaProcessos.waitFor({
      state: "visible",
      timeout: localElementTimeoutMs,
    });

    register("Clicando em Consulta Processos");
    await consultaProcessos.click();

    register("Tela Consulta Processos acionada", "proximo marco=campo Sinistro");
  }

  async function fillSinistro() {
    const frame = page.frameLocator("#iframe_funcionalidade");
    const sinistroInput = frame.locator("#cd_vistoria_sinistro_param");
    const sinistro = osItem.dadosOs?.sinistro;

    if (!sinistro) {
      throw new Error(`OS ${osItem.os} sem sinistro retornado pela API.`);
    }

    register("Validando existencia do campo Sinistro");
    const sinistroExists = await sinistroInput
      .waitFor({ state: "attached", timeout: localElementTimeoutMs })
      .then(() => true)
      .catch(() => false);

    if (!sinistroExists || (await sinistroInput.count()) === 0) {
      register("Campo Sinistro nao existe no DOM");
      return;
    }

    register("Aguardando campo Sinistro", `timeout=${localElementTimeoutMs}ms`);
    await sinistroInput.waitFor({
      state: "visible",
      timeout: localElementTimeoutMs,
    });

    register("Preenchendo campo Sinistro", `valor=${sinistro}`);
    await sinistroInput.fill(sinistro);
  }

  async function clickPesquisar() {
    const frame = page.frameLocator("#iframe_funcionalidade");
    const pesquisarButton = frame
      .getByRole("button", { name: /pesquisar/i })
      .or(
        frame.locator(
          'button:has-text("Pesquisar"), input[type="button"][value*="Pesquisar" i], input[type="submit"][value*="Pesquisar" i]'
        )
      )
      .first();

    register("Validando existencia do botao Pesquisar");
    const pesquisarExists = await pesquisarButton
      .waitFor({ state: "attached", timeout: localElementTimeoutMs })
      .then(() => true)
      .catch(() => false);

    if (!pesquisarExists || (await pesquisarButton.count()) === 0) {
      register("Botao Pesquisar nao existe no DOM");
      return;
    }

    register("Aguardando botao Pesquisar", `timeout=${localElementTimeoutMs}ms`);
    await pesquisarButton.waitFor({
      state: "visible",
      timeout: localElementTimeoutMs,
    });

    register("Clicando em Pesquisar");
    await pesquisarButton.click();

    register("Pesquisa acionada");
  }

  async function validateFaturamentoAndClick() {
    const frameLocator = page.frameLocator("#iframe_funcionalidade");
    const faturamentoText = frameLocator.getByText(
      /Dispon[ií]vel\s+para\s+Faturamento/i
    );
    const cliqueAqui = frameLocator
      .getByRole("button", { name: /clique aqui/i })
      .or(frameLocator.getByRole("link", { name: /clique aqui/i }))
      .or(frameLocator.getByText(/clique aqui/i))
      .first();

    register("Aguardando resultado da pesquisa", "timeout=3000ms");
    await page.waitForTimeout(3_000);

    register("Validando status do sinistro", "texto=Disponível para Faturamento");
    const isAvailableByLocator = await faturamentoText
      .first()
      .isVisible({ timeout: localElementTimeoutMs })
      .catch(() => false);
    const funcionalidadeFrame = page.frame({ name: "iframe_funcionalidade" });
    const isAvailableByText = funcionalidadeFrame
      ? await funcionalidadeFrame
          .locator("body")
          .innerText({ timeout: localElementTimeoutMs })
          .then((text) => /Dispon[ií]vel\s+para\s+Faturamento/i.test(text))
          .catch(() => false)
      : false;

    if (!isAvailableByLocator && !isAvailableByText) {
      await page.screenshot({
        path: "tokio-faturamento-nao-disponivel.png",
        fullPage: true,
      });
      throw new Error('Texto "Disponível para Faturamento" nao encontrado.');
    }

    register("Status do sinistro encontrado", "Disponível para Faturamento");

    register("Validando existencia do CLIQUE AQUI");
    const cliqueAquiExists = await cliqueAqui
      .waitFor({ state: "attached", timeout: localElementTimeoutMs })
      .then(() => true)
      .catch(() => false);

    if (!cliqueAquiExists || (await cliqueAqui.count()) === 0) {
      throw new Error('Acao "CLIQUE AQUI" nao encontrada.');
    }

    register("Clicando em CLIQUE AQUI");
    await cliqueAqui.click();
  }

  async function clickInformacoesFaturamento() {
    const frame = page.frameLocator("#iframe_funcionalidade");
    const solicitarPagamento = frame
      .locator("#solicitarpagamento")
      .or(frame.getByText(/Informa[cç][oõ]es de Faturamento/i))
      .first();

    register(
      "Aguardando tela de detalhes do sinistro",
      `timeout=${faturamentoScreenTimeoutMs}ms`
    );
    await page.waitForTimeout(faturamentoScreenTimeoutMs);

    register("Validando existencia do botao Informacoes de Faturamento");
    const solicitarPagamentoExists = await solicitarPagamento
      .waitFor({ state: "attached", timeout: faturamentoScreenTimeoutMs })
      .then(() => true)
      .catch(() => false);

    if (!solicitarPagamentoExists || (await solicitarPagamento.count()) === 0) {
      throw new Error('Botao "Informações de Faturamento" nao encontrado.');
    }

    register(
      "Aguardando botao Informacoes de Faturamento",
      `timeout=${faturamentoScreenTimeoutMs}ms`
    );
    await solicitarPagamento.waitFor({
      state: "visible",
      timeout: faturamentoScreenTimeoutMs,
    });

    register("Clicando em Informacoes de Faturamento");
    await solicitarPagamento.click();
  }

  async function selectDocumentoFiscalAndCollectCnpj() {
    const frameLocator = page.frameLocator("#iframe_funcionalidade");
    const funcionalidadeFrame = page.frame({ name: "iframe_funcionalidade" });

    if (!funcionalidadeFrame) {
      throw new Error("Frame iframe_funcionalidade nao encontrado.");
    }

    const tipoDocumentoFiscalOptions = frameLocator.locator(
      'input[type="radio"][id="cd_tipo_doc_fiscal_tela"]'
    );
    const tipoDocumentoFiscal = frameLocator
      .locator('input[type="radio"][id="cd_tipo_doc_fiscal_tela"]')
      .first();
    const conteudoSucursal = frameLocator.locator(
      "#divConteudoSucursalFaturamento strong"
    );

    register(
      "Aguardando opcao Documento Fiscal",
      `label=Mao de Obra | timeout=${faturamentoScreenTimeoutMs}ms`
    );
    const tipoDocumentoFiscalExists = await tipoDocumentoFiscal
      .waitFor({ state: "attached", timeout: faturamentoScreenTimeoutMs })
      .then(() => true)
      .catch(() => false);

    if (!tipoDocumentoFiscalExists || (await tipoDocumentoFiscal.count()) === 0) {
      throw new Error('Opcao "Documento Fiscal" nao encontrada.');
    }

    register(
      "Opcoes Documento Fiscal encontradas",
      `total=${await tipoDocumentoFiscalOptions.count()}`
    );
    register("Clicando na opcao Documento Fiscal", "label=Mao de Obra");
    await tipoDocumentoFiscal.scrollIntoViewIfNeeded();
    await tipoDocumentoFiscal.click({ timeout: faturamentoScreenTimeoutMs });

    let tipoDocumentoFiscalChecked = await tipoDocumentoFiscal.isChecked();

    if (!tipoDocumentoFiscalChecked) {
      register(
        "Opcao Documento Fiscal nao marcou no primeiro clique",
        "tentando check forcado"
      );
      await tipoDocumentoFiscal.check({ force: true });
      tipoDocumentoFiscalChecked = await tipoDocumentoFiscal.isChecked();
    }

    if (!tipoDocumentoFiscalChecked) {
      register(
        "Opcao Documento Fiscal ainda nao marcada",
        "marcando via DOM e disparando eventos"
      );
      await funcionalidadeFrame.evaluate(() => {
        const radios = document.querySelectorAll(
          'input[type="radio"][id="cd_tipo_doc_fiscal_tela"]'
        );
        const maoDeObra = radios[0];

        if (!maoDeObra) {
          throw new Error('Opcao "Mao de Obra" nao encontrada no frame.');
        }

        maoDeObra.checked = true;
        maoDeObra.dispatchEvent(new MouseEvent("click", { bubbles: true }));
        maoDeObra.dispatchEvent(new Event("change", { bubbles: true }));
      });
      tipoDocumentoFiscalChecked = await tipoDocumentoFiscal.isChecked();
    }

    if (!tipoDocumentoFiscalChecked) {
      throw new Error('Opcao "Mao de Obra" nao foi marcada.');
    }

    register("Opcao Documento Fiscal marcada", "label=Mao de Obra");

    register(
      "Aguardando dados da sucursal de faturamento",
      "id=divConteudoSucursalFaturamento"
    );
    let conteudoSucursalExists = await funcionalidadeFrame
      .waitForFunction(
        () => {
          const text =
            document.querySelector("#divConteudoSucursalFaturamento strong")
              ?.textContent || "";

          return /\b\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}\b/.test(text);
        },
        undefined,
        { timeout: faturamentoScreenTimeoutMs }
      )
      .then(() => true)
      .catch(() => false);

    if (!conteudoSucursalExists) {
      register(
        "Dados da sucursal ainda nao carregaram",
        "executando fallback getCnpjValidosFaturamento/verificarCnpjEmitir"
      );
      await funcionalidadeFrame.evaluate(() => {
        if (typeof getCnpjValidosFaturamento === "function") {
          getCnpjValidosFaturamento();
        }

        if (typeof verificarCnpjEmitir === "function") {
          verificarCnpjEmitir();
        }
      });

      conteudoSucursalExists = await funcionalidadeFrame
        .waitForFunction(
          () => {
            const text =
              document.querySelector("#divConteudoSucursalFaturamento strong")
                ?.textContent || "";

            return /\b\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}\b/.test(text);
          },
          undefined,
          { timeout: faturamentoScreenTimeoutMs }
        )
        .then(() => true)
        .catch(() => false);
    }

    if (!conteudoSucursalExists || (await conteudoSucursal.count()) === 0) {
      throw new Error("Dados da sucursal de faturamento nao encontrados.");
    }

    const sucursalFaturamentoTexto = (await conteudoSucursal.innerText()).trim();
    const cnpjMatch = sucursalFaturamentoTexto.match(
      /\b\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}\b/
    );

    if (!cnpjMatch) {
      throw new Error("CNPJ da sucursal de faturamento nao encontrado.");
    }

    const collectedData = {
      osId: osItem.id,
      os: osItem.os,
      sinistro: osItem.dadosOs?.sinistro,
      cnpjSucursalFaturamento: cnpjMatch[0],
      sucursalFaturamentoTexto,
    };

    register("CNPJ da sucursal coletado", collectedData.cnpjSucursalFaturamento);
    register("Sucesso", "dados de faturamento coletados");

    return collectedData;
  }

  async function persistSuccessfulValidation(collectedData) {
    const apiCnpj = osItem.seguradora?.cnpj;
    const siteCnpj = collectedData.cnpjSucursalFaturamento;
    const cnpjMatches = normalizeCnpj(apiCnpj) === normalizeCnpj(siteCnpj);
    const occurrenceDate = formatPtBrDateTime();

    const result = {
      sucesso: cnpjMatches,
      osId: osItem.id,
      os: osItem.os,
      codigoConference: osItem.codigoConference,
      sinistro: osItem.dadosOs?.sinistro,
      seguradora: osItem.seguradora?.nome,
      cnpjSeguradoraApi: apiCnpj,
      cnpjSucursalFaturamento: siteCnpj,
      sucursalFaturamentoTexto: collectedData.sucursalFaturamentoTexto,
      cnpjCorresponde: cnpjMatches,
      ocorrencia: cnpjMatches
        ? `CNPJ VALIDADO NO SITE DA TOKIO, DATA ${occurrenceDate}. OK, Conferido.`
        : `CNPJ DIVERGENTE NO SITE DA TOKIO, DATA ${occurrenceDate}. API=${apiCnpj} SITE=${siteCnpj}.`,
    };

    if (!cnpjMatches) {
      throw new Error(result.ocorrencia);
    }

    register("CNPJ corresponde", `api=${apiCnpj} | site=${siteCnpj}`);
    await redisSet(host, redisKey, {
      verificado: true,
      cnpj: siteCnpj,
      validado: true,
      ocorrencia: "",
      dadosRPA: {
        sinistro: collectedData.sinistro,
        cnpjSucursalFaturamento: collectedData.cnpjSucursalFaturamento,
        sucursalFaturamentoTexto: collectedData.sucursalFaturamentoTexto,
      },
    });
    register("Redis atualizado", `key=${redisKey}`);

    await httpJson(`${host}/dashboard/consolidacoes/${osItem.os}/cnpj`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(true),
    });
    register("Consolidacao CNPJ atualizada", `os=${osItem.os}`);

    console.log(JSON.stringify(result, null, 2));
    return result;
  }

  page.on("console", (message) => {
    if (message.type() === "error") {
      diagnostics.consoleErrors += 1;
    }

    if (message.type() === "warning") {
      diagnostics.consoleWarnings += 1;
    }
  });

  page.on("pageerror", (error) => {
    diagnostics.pageErrors += 1;
  });

  page.on("requestfailed", (request) => {
    diagnostics.failedRequests += 1;
  });

  page.on("response", (response) => {
    if (response.status() >= 400) {
      diagnostics.httpErrors += 1;
    }
  });

  const url =
    "https://ssoportais3.tokiomarine.com.br/openam/XUI/?realm=TOKIOLFR&goto=http://portalparceiros.tokiomarine.com.br/#login/";

  try {
    register("Abrindo URL inicial");
    const response = await page.goto(url, {
      waitUntil: "commit",
      timeout: 10_000,
    });

    await waitForLoginScreen();

    const usernameInput = page.locator("input").nth(0);
    const passwordInput = page.locator("input").nth(1);

    register("Preenchendo credenciais", `usuario=${credential.usuario}`);
    await usernameInput.fill(credential.usuario);
    await passwordInput.fill(credential.senha);
    register("Clicando em ENTRAR");
    await page.getByRole("button", { name: /entrar/i }).click();

    register("Aguardando portal", "marco=link Oficina");
    const oficinaLink = page.getByRole("link", { name: /oficina/i });
    await oficinaLink.waitFor({ state: "visible", timeout: 60_000 });
    register("Clicando em Oficina");
    await oficinaLink.click();
    await page.waitForLoadState("domcontentloaded");

    register("Aguardando tela Portal Oficina", "marco=Dados Cadastrais ou PORTAL OFICINA");
    await page
      .getByText(/Dados Cadastrais|PORTAL OFICINA/i)
      .first()
      .waitFor({ state: "visible", timeout: 60_000 });
    register("Tela Portal Oficina carregada");
    await closeOficinaPopup();
    await openConsultaProcessos();
    await fillSinistro();
    await clickPesquisar();
    await validateFaturamentoAndClick();
    await clickInformacoesFaturamento();
    const collectedData = await selectDocumentoFiscalAndCollectCnpj();
    await persistSuccessfulValidation(collectedData);

    register("Salvando screenshot", "arquivo=tokio-login.png");
    await page.screenshot({
      path: "tokio-login.png",
      fullPage: true,
    });

    await page.context().tracing.stop().catch(() => {});
    register(
      "Fluxo concluido",
      `statusInicial=${response?.status()} | urlFinal=${page.url()} | titulo=${await page.title()}`
    );
    register(
      "Diagnostico silencioso",
      `http>=400=${diagnostics.httpErrors} | consoleErrors=${diagnostics.consoleErrors} | warnings=${diagnostics.consoleWarnings} | pageErrors=${diagnostics.pageErrors} | failedRequests=${diagnostics.failedRequests}`
    );
    register("Script finalizado", "navegador mantido aberto para inspecao");
  } catch (error) {
    register("Falha durante o acesso", error.message);
    console.log(
      JSON.stringify(
        {
          sucesso: false,
          osId: osItem.id,
          os: osItem.os,
          codigoConference: osItem.codigoConference,
          sinistro: osItem.dadosOs?.sinistro,
          erro: error.message,
        },
        null,
        2
      )
    );
  }

  // Mantém aberto para inspeção manual.
  if (env.KEEP_OPEN !== "false") {
    await new Promise(() => {});
  }

  await browser.close();
})().catch((error) => {
  console.log(
    JSON.stringify(
      {
        sucesso: false,
        erro: error.message,
      },
      null,
      2
    )
  );
  process.exitCode = 1;
});
